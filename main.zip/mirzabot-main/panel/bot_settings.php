<?php
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/icons.php';
require_auth();

// Fetch settings
try {
    $row = db_fetch($pdo, "SELECT * FROM setting LIMIT 1");
} catch (Exception $e) {
    $row = [];
}

$pay_settings = [];
try {
    $stmt = $pdo->query("SELECT NamePay, ValuePay FROM PaySetting");
    while($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if ($r['NamePay'] === 'minbalance' || $r['NamePay'] === 'maxbalance') {
            $decoded = json_decode($r['ValuePay'], true);
            if (is_array($decoded)) {
                $pay_settings[$r['NamePay']] = $decoded['n'] ?? ($decoded['allusers'] ?? '');
                $pay_settings[$r['NamePay'] . 'paynotverify_from_json'] = $decoded['f'] ?? '';
            } else {
                $pay_settings[$r['NamePay']] = $r['ValuePay'];
            }
        } else {
            $pay_settings[$r['NamePay']] = $r['ValuePay'];
        }
    }
    if (isset($pay_settings['minbalancepaynotverify_from_json']) && $pay_settings['minbalancepaynotverify_from_json'] !== '') {
        $pay_settings['minbalancepaynotverify'] = $pay_settings['minbalancepaynotverify_from_json'];
    }
    if (isset($pay_settings['maxbalancepaynotverify_from_json']) && $pay_settings['maxbalancepaynotverify_from_json'] !== '') {
        $pay_settings['maxbalancepaynotverify'] = $pay_settings['maxbalancepaynotverify_from_json'];
    }
} catch (Exception $e) {}

try {
    $stmt = $pdo->query("SELECT cardnumber, namecard FROM card_number LIMIT 1");
    if($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $pay_settings['cardnumber'] = $r['cardnumber'];
        $pay_settings['namecard'] = $r['namecard'];
    }
} catch (Exception $e) {}

$shop_settings = [];
try {
    $stmt = $pdo->query("SELECT Namevalue, value FROM shopSetting");
    while($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if ($r['Namevalue'] === 'chashbackextend_agent') {
            $decoded = json_decode($r['value'], true);
            if (is_array($decoded)) {
                $shop_settings['chashbackextend_agent_n'] = $decoded['n'] ?? 0;
                $shop_settings['chashbackextend_agent_n2'] = $decoded['n2'] ?? 0;
            }
        } else {
            $shop_settings[$r['Namevalue']] = $r['value'];
        }
    }
} catch (Exception $e) {}

$affiliate_settings = [];
try {
    $stmt = $pdo->query("SELECT * FROM affiliates LIMIT 1");
    if($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $affiliate_settings = $r;
    }
} catch (Exception $e) {}

$cron_status = json_decode($row['cron_status'] ?? '{}', true);
$limitnumber = json_decode($row['limitnumber'] ?? '{}', true);
$lottery_prize = json_decode($row['Lottery_prize'] ?? '{}', true);

$schema = [
    'general' => [
        'title' => 'عمومی',
        'icon' => 'settings',
        'sections' => [
            'وضعیت و دسترسی' => [
                ['name' => 'set_Bot_Status', 'label' => 'وضعیت ربات', 'type' => 'select', 'options' => ['botstatuson' => 'روشن', 'botstatusoff' => 'خاموش'], 'val' => $row['Bot_Status'] ?? ''],
                ['name' => 'set_roll_Status', 'label' => 'تایید قوانین', 'type' => 'select', 'options' => ['rolleon' => 'اجباری', 'rolleoff' => 'اختیاری'], 'val' => $row['roll_Status'] ?? ''],
                ['name' => 'set_NotUser', 'label' => 'قفل برای غیرکاربران', 'type' => 'select', 'options' => ['onnotuser' => 'فعال', 'offnotuser' => 'غیرفعال'], 'val' => $row['NotUser'] ?? ''],
                ['name' => 'set_statusnewuser', 'label' => 'وضعیت کاربران جدید', 'type' => 'select', 'options' => ['onnewuser' => 'آزاد', 'offnewuser' => 'بسته'], 'val' => $row['statusnewuser'] ?? ''],
                ['name' => 'set_verifystart', 'label' => 'تاییدیه شروع کار', 'type' => 'select', 'options' => ['onverify' => 'فعال', 'offverify' => 'غیرفعال'], 'val' => $row['verifystart'] ?? ''],
                ['name' => 'set_verifybucodeuser', 'label' => 'تاییدیه پیامکی (کد)', 'type' => 'select', 'options' => ['onverify' => 'فعال', 'offverify' => 'غیرفعال'], 'val' => $row['verifybucodeuser'] ?? ''],
                ['name' => 'set_get_number', 'label' => 'دریافت شماره تماس', 'type' => 'select', 'options' => ['onAuthenticationphone' => 'اجباری', 'offAuthenticationphone' => 'اختیاری/خاموش'], 'val' => $row['get_number'] ?? ''],
                ['name' => 'set_iran_number', 'label' => 'فقط شماره ایران', 'type' => 'select', 'options' => ['onAuthenticationiran' => 'بله', 'offAuthenticationiran' => 'خیر'], 'val' => $row['iran_number'] ?? ''],
                ['name' => 'set_limitnumber_free', 'label' => 'محدودیت (کاربران رایگان)', 'type' => 'number', 'val' => $limitnumber['free'] ?? '100'],
                ['name' => 'set_limitnumber_all', 'label' => 'محدودیت (همه کاربران)', 'type' => 'number', 'val' => $limitnumber['all'] ?? '100'],
                ['name' => 'set_numbercount', 'label' => 'محدودیت اکانت با هر شماره', 'type' => 'number', 'val' => $row['numbercount'] ?? '0'],
                ['name' => 'set_timeauto_not_verify', 'label' => 'زمان حذف تایید نشده (روز)', 'type' => 'number', 'val' => $row['timeauto_not_verify'] ?? '4'],
            ],
            'گزارشات و ارتباطات' => [
                ['name' => 'set_Channel_Report', 'label' => 'آیدی کانال گزارشات', 'type' => 'text', 'placeholder' => '-100xxxxxxxxx', 'val' => $row['Channel_Report'] ?? ''],
                ['name' => 'set_id_support', 'label' => 'آیدی پشتیبانی', 'type' => 'text', 'placeholder' => '123456789', 'val' => $row['id_support'] ?? ''],
                ['name' => 'set_statussupportpv', 'label' => 'پشتیبانی PV', 'type' => 'select', 'options' => ['onpvsupport' => 'فعال', 'offpvsupport' => 'غیرفعال'], 'val' => $row['statussupportpv'] ?? ''],
                ['name' => 'set_categoryhelp', 'label' => 'راهنما در دسته‌بندی‌ها', 'type' => 'select', 'options' => ['1' => 'نمایش', '0' => 'عدم نمایش'], 'val' => $row['categoryhelp'] ?? ''],
                ['name' => 'set_linkappstatus', 'label' => 'لینک اپلیکیشن در منو', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => $row['linkappstatus'] ?? ''],
                ['name' => 'set_statusnoteforf', 'label' => 'یادداشت اجباری در خرید', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => $row['statusnoteforf'] ?? ''],
            ],
            'کاربر و سرویس' => [
                ['name' => 'set_limit_usertest_all', 'label' => 'تعداد تست مجاز هر کاربر', 'type' => 'number', 'val' => $row['limit_usertest_all'] ?? ''],
                ['name' => 'set_removedayc', 'label' => 'روزهای نگهداری سرویس حذف شده', 'type' => 'number', 'val' => $row['removedayc'] ?? ''],
                ['name' => 'set_on_hold_day', 'label' => 'روزهای مسدودی موقت', 'type' => 'number', 'val' => $row['on_hold_day'] ?? ''],
                ['name' => 'set_cronvolumere', 'label' => 'بررسی حجم کرون‌جاب (ساعت)', 'type' => 'number', 'val' => $row['cronvolumere'] ?? ''],
                ['name' => 'set_daywarn', 'label' => 'هشدار پایان سرویس (روز)', 'type' => 'number', 'val' => $row['daywarn'] ?? ''],
                ['name' => 'set_volumewarn', 'label' => 'هشدار پایان حجم (گیگابایت)', 'type' => 'number', 'val' => $row['volumewarn'] ?? ''],
                ['name' => 'set_statusnamecustom', 'label' => 'نام سفارشی سرویس‌ها', 'type' => 'select', 'options' => ['onnamecustom' => 'فعال', 'offnamecustom' => 'غیرفعال'], 'val' => $row['statusnamecustom'] ?? ''],
            ],
            'ظاهر و منوها' => [
                ['name' => 'set_inlinebtnmain', 'label' => 'دکمه‌های شیشه‌ای منوی اصلی', 'type' => 'select', 'options' => ['oninline' => 'روشن', 'offinline' => 'خاموش'], 'val' => $row['inlinebtnmain'] ?? ''],
                ['name' => 'set_btn_status_extned', 'label' => 'دکمه تمدید سرویس', 'type' => 'select', 'options' => ['1' => 'روشن', '0' => 'خاموش'], 'val' => $row['btn_status_extned'] ?? ''],
                ['name' => 'set_status_keyboard_config', 'label' => 'کیبورد تنظیمات کانفیگ', 'type' => 'select', 'options' => ['1' => 'روشن', '0' => 'خاموش'], 'val' => $row['status_keyboard_config'] ?? ''],
                ['name' => 'set_status_manual_config', 'label' => 'دریافت دستی کانفیگ (QR)', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => $row['status_manual_config'] ?? '1'],
                ['name' => 'custom_qr_background', 'label' => 'پس‌زمینه اصلی بارکد (custom.jpg)', 'type' => 'file', 'accept' => 'image/jpeg', 'hint' => 'تصویر با فرمت jpg'],
                ['name' => 'images_qr_background', 'label' => 'پس‌زمینه جایگزین بارکد (images.jpg)', 'type' => 'file', 'accept' => 'image/jpeg', 'hint' => 'تصویر با فرمت jpg'],
            ],
            'مدیریت کرون‌جاب' => [
                ['name' => 'set_cron_day', 'label' => 'محاسبه روزها (day)', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => ($cron_status['day'] ?? true) ? '1' : '0'],
                ['name' => 'set_cron_volume', 'label' => 'محاسبه حجم (volume)', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => ($cron_status['volume'] ?? true) ? '1' : '0'],
                ['name' => 'set_cron_remove', 'label' => 'حذف پایان‌یافته', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => ($cron_status['remove'] ?? false) ? '1' : '0'],
                ['name' => 'set_cron_remove_volume', 'label' => 'حذف تمام‌شده', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => ($cron_status['remove_volume'] ?? false) ? '1' : '0'],
                ['name' => 'set_cron_test', 'label' => 'حذف سرویس تست', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => ($cron_status['test'] ?? false) ? '1' : '0'],
                ['name' => 'set_cron_on_hold', 'label' => 'مسدودی موقت', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => ($cron_status['on_hold'] ?? false) ? '1' : '0'],
                ['name' => 'set_cron_uptime_node', 'label' => 'پایداری نودها', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => ($cron_status['uptime_node'] ?? false) ? '1' : '0'],
                ['name' => 'set_cron_uptime_panel', 'label' => 'پایداری پنل‌ها', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => ($cron_status['uptime_panel'] ?? false) ? '1' : '0'],
            ]
        ]
    ],
    'gamification' => [
        'title' => 'سرگرمی و امتیاز',
        'icon' => 'star',
        'sections' => [
            'گردونه شانس' => [
                ['name' => 'set_wheelـluck', 'label' => 'وضعیت گردونه', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => $row['wheelـluck'] ?? ''],
                ['name' => 'set_wheelـluck_price', 'label' => 'قیمت هر چرخش (تومان)', 'type' => 'number', 'val' => $row['wheelـluck_price'] ?? '0'],
                ['name' => 'set_statusfirstwheel', 'label' => 'اولین چرخش رایگان', 'type' => 'select', 'options' => ['1' => 'بله', '0' => 'خیر'], 'val' => $row['statusfirstwheel'] ?? ''],
                ['name' => 'set_wheelagent', 'label' => 'گردونه برای نمایندگان', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => $row['wheelagent'] ?? ''],
                ['name' => 'set_prize_one', 'label' => 'جایزه سطح 1', 'type' => 'number', 'val' => $lottery_prize['one'] ?? '0'],
                ['name' => 'set_prize_tow', 'label' => 'جایزه سطح 2', 'type' => 'number', 'val' => $lottery_prize['tow'] ?? '0'],
                ['name' => 'set_prize_theree', 'label' => 'جایزه سطح 3', 'type' => 'number', 'val' => $lottery_prize['theree'] ?? '0'],
            ],
            'سایر بازی‌ها و امتیازات' => [
                ['name' => 'set_Dice', 'label' => 'بازی تاس', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => $row['Dice'] ?? ''],
                ['name' => 'set_scorestatus', 'label' => 'سیستم امتیازدهی', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => $row['scorestatus'] ?? ''],
                ['name' => 'set_Lotteryagent', 'label' => 'قرعه‌کشی نمایندگان', 'type' => 'select', 'options' => ['1' => 'فعال', '0' => 'غیرفعال'], 'val' => $row['Lotteryagent'] ?? ''],
            ]
        ]
    ]
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check_post();
    
    $updates_setting = [];
    $params_setting = [];
    $new_cardnumber = null;
    $new_namecard = null;
    
    $new_cron_status = json_decode($row['cron_status'] ?? '{}', true);
    if (!is_array($new_cron_status)) $new_cron_status = [];
    
    $new_limitnumber = json_decode($row['limitnumber'] ?? '{}', true);
    if (!is_array($new_limitnumber)) $new_limitnumber = [];
    
    $new_lottery_prize = json_decode($row['Lottery_prize'] ?? '{}', true);
    if (!is_array($new_lottery_prize)) $new_lottery_prize = [];
    
    $new_chashbackextend_agent = ['n' => 0, 'n2' => 0];
    $stmt = $pdo->query("SELECT value FROM shopSetting WHERE Namevalue = 'chashbackextend_agent'");
    if($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $dec = json_decode($r['value'], true);
        if(is_array($dec)) $new_chashbackextend_agent = $dec;
    }
    
    $updates_affiliates = [];
    $params_affiliates = [];
    
    // File Uploads
    if (isset($_FILES['custom_qr_background'])) {
        if ($_FILES['custom_qr_background']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['custom_qr_background']['tmp_name'];
            $fileType = strtolower(pathinfo($_FILES['custom_qr_background']['name'], PATHINFO_EXTENSION));
            if (in_array($fileType, ['jpg', 'jpeg'])) {
                if (move_uploaded_file($tmpName, __DIR__ . '/../custom.jpg')) {
                    $success = "تصویر پس‌زمینه اصلی (custom.jpg) با موفقیت به‌روزرسانی شد.<br>";
                } else {
                    $error = "خطا در ذخیره تصویر پس‌زمینه اصلی (احتمالاً مشکل سطح دسترسی).<br>";
                }
            } else {
                $error = "فایل پس‌زمینه اصلی باید jpg باشد.<br>";
            }
        } elseif ($_FILES['custom_qr_background']['error'] !== UPLOAD_ERR_NO_FILE) {
            $error = "خطا در آپلود پس‌زمینه اصلی (کد خطا: " . $_FILES['custom_qr_background']['error'] . "). حجم فایل ممکن است زیاد باشد.<br>";
        }
    }
    
    if (isset($_FILES['images_qr_background'])) {
        if ($_FILES['images_qr_background']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['images_qr_background']['tmp_name'];
            $fileType = strtolower(pathinfo($_FILES['images_qr_background']['name'], PATHINFO_EXTENSION));
            if (in_array($fileType, ['jpg', 'jpeg'])) {
                if (move_uploaded_file($tmpName, __DIR__ . '/../images.jpg')) {
                    $success .= "تصویر پس‌زمینه جایگزین (images.jpg) با موفقیت به‌روزرسانی شد.<br>";
                } else {
                    $error .= "خطا در ذخیره تصویر پس‌زمینه جایگزین (احتمالاً مشکل سطح دسترسی).<br>";
                }
            } else {
                $error .= "فایل پس‌زمینه جایگزین باید jpg باشد.<br>";
            }
        } elseif ($_FILES['images_qr_background']['error'] !== UPLOAD_ERR_NO_FILE) {
            $error .= "خطا در آپلود پس‌زمینه جایگزین (کد خطا: " . $_FILES['images_qr_background']['error'] . "). حجم فایل ممکن است زیاد باشد.<br>";
        }
    }
    
    foreach($_POST as $key => $val) {
        if(strpos($key, 'set_cron_') === 0) {
            $field = substr($key, 9);
            $new_cron_status[$field] = ($val === '1');
        } elseif(strpos($key, 'set_limitnumber_') === 0) {
            $field = substr($key, 16);
            $new_limitnumber[$field] = intval($val);
        } elseif(strpos($key, 'set_prize_') === 0) {
            $field = substr($key, 10);
            $new_lottery_prize[$field] = strval($val);
        } elseif(strpos($key, 'set_') === 0) {
            $field = substr($key, 4);
            $updates_setting[] = "$field = ?";
            $params_setting[] = $val;
            
            // Sync test limit to all users if limit_usertest_all is updated
            if ($field === 'limit_usertest_all') {
                db_query($pdo, "UPDATE user SET limit_usertest = ?", [$val]);
            }
        } elseif(strpos($key, 'pay_') === 0) {
            $field = substr($key, 4);
            if ($field === 'cardnumber') {
                $new_cardnumber = $val;
            } elseif ($field === 'namecard') {
                $new_namecard = $val;
            } elseif ($field === 'minbalance' || $field === 'maxbalance') {
                $old_json = db_fetch($pdo, "SELECT ValuePay FROM PaySetting WHERE NamePay = ?", [$field])['ValuePay'] ?? '';
                $decoded = json_decode($old_json, true);
                if (!is_array($decoded)) $decoded = [];
                $decoded['n'] = $val;
                $decoded['n2'] = $val;
                $decoded['allusers'] = $val;
                db_query($pdo, "UPDATE PaySetting SET ValuePay = ? WHERE NamePay = ?", [json_encode($decoded), $field]);
            } elseif ($field === 'minbalancepaynotverify') {
                db_query($pdo, "UPDATE PaySetting SET ValuePay = ? WHERE NamePay = ?", [$val, $field]);
                $old_json = db_fetch($pdo, "SELECT ValuePay FROM PaySetting WHERE NamePay = ?", ['minbalance'])['ValuePay'] ?? '';
                $decoded = json_decode($old_json, true);
                if (!is_array($decoded)) $decoded = [];
                $decoded['f'] = $val;
                db_query($pdo, "UPDATE PaySetting SET ValuePay = ? WHERE NamePay = ?", [json_encode($decoded), 'minbalance']);
            } elseif ($field === 'maxbalancepaynotverify') {
                db_query($pdo, "UPDATE PaySetting SET ValuePay = ? WHERE NamePay = ?", [$val, $field]);
                $old_json = db_fetch($pdo, "SELECT ValuePay FROM PaySetting WHERE NamePay = ?", ['maxbalance'])['ValuePay'] ?? '';
                $decoded = json_decode($old_json, true);
                if (!is_array($decoded)) $decoded = [];
                $decoded['f'] = $val;
                db_query($pdo, "UPDATE PaySetting SET ValuePay = ? WHERE NamePay = ?", [json_encode($decoded), 'maxbalance']);
            } else {
                db_query($pdo, "UPDATE PaySetting SET ValuePay = ? WHERE NamePay = ?", [$val, $field]);
            }
        } elseif(strpos($key, 'shop_chashbackextend_agent_') === 0) {
            $field = substr($key, 27);
            $new_chashbackextend_agent[$field] = intval($val);
        } elseif(strpos($key, 'shop_') === 0) {
            $field = substr($key, 5);
            db_query($pdo, "UPDATE shopSetting SET value = ? WHERE Namevalue = ?", [$val, $field]);
        } elseif(strpos($key, 'aff_') === 0) {
            $field = substr($key, 4);
            $updates_affiliates[] = "$field = ?";
            $params_affiliates[] = $val;
        }
    }
    
    $updates_setting[] = "cron_status = ?";
    $params_setting[] = json_encode($new_cron_status);
    
    $updates_setting[] = "limitnumber = ?";
    $params_setting[] = json_encode($new_limitnumber);
    
    $updates_setting[] = "Lottery_prize = ?";
    $params_setting[] = json_encode($new_lottery_prize);
    
    db_query($pdo, "UPDATE shopSetting SET value = ? WHERE Namevalue = ?", [json_encode($new_chashbackextend_agent), 'chashbackextend_agent']);
    
    if(!empty($updates_affiliates)) {
        db_query($pdo, "UPDATE affiliates SET " . implode(', ', $updates_affiliates), $params_affiliates);
    }
    
    if ($new_cardnumber !== null && $new_namecard !== null) {
        $old = db_fetch($pdo, "SELECT cardnumber, namecard FROM card_number LIMIT 1");
        $old_card = $old ? $old['cardnumber'] : null;
        if ($old_card !== $new_cardnumber || ($old && $old['namecard'] !== $new_namecard) || !$old) {
            db_query($pdo, "DELETE FROM card_number");
            if ($new_cardnumber) {
                db_query($pdo, "INSERT IGNORE INTO card_number (cardnumber, namecard) VALUES (?, ?)", [$new_cardnumber, $new_namecard]);
            }
        }
    }
    
    if(!empty($updates_setting)) {
        db_query($pdo, "UPDATE setting SET " . implode(', ', $updates_setting), $params_setting);
    }

    if (!empty($error)) {
        flash('error', $error . '<br>سایر تنظیمات ذخیره شدند.');
    } else {
        $final_success = $textbotlang['panel']['botSettingsSuccess'] ?? 'تنظیمات با موفقیت ذخیره شد.';
        if (!empty($success)) {
            $final_success = $success . '<br>' . $final_success;
        }
        flash('success', $final_success);
    }
    
    $redirect_tab = $_POST['current_tab'] ?? 'general';
    $redirect_sec = $_POST['current_sec'] ?? '';
    header('Location: bot_settings.php?tab=' . urlencode($redirect_tab) . '&sec=' . urlencode($redirect_sec));
    exit;
}

$tab = $_GET['tab'] ?? 'general';
if (!array_key_exists($tab, $schema)) {
    $tab = 'general';
}

$sections = array_keys($schema[$tab]['sections']);
$sec = $_GET['sec'] ?? $sections[0];
if (!in_array($sec, $sections)) {
    $sec = $sections[0];
}

$pageTitle = 'تنظیمات عمومی و سرگرمی';
$activeNav = 'bot_settings';
include __DIR__ . '/inc/layout_head.php';
?>

<style>
.arvan-layout {
    display: flex;
    flex-direction: column;
    gap: 20px;
    margin-bottom: 30px;
}
.arvan-main-tabs {
    display: flex;
    gap: 15px;
    overflow-x: auto;
    padding-bottom: 10px;
    margin-bottom: 15px;
}
.arvan-main-tab-btn {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 20px;
    background: var(--sf);
    border: 1px solid var(--bd);
    border-radius: 12px;
    color: var(--text2);
    cursor: pointer;
    transition: all 0.2s;
    font-size: 0.95rem;
    white-space: nowrap;
    outline: none;
}
.arvan-main-tab-btn.active {
    background: var(--ac);
    color: var(--btn-ac-text, #fff);
    border-color: var(--ac);
    box-shadow: 0 4px 15px var(--acs);
}
.arvan-main-tab-btn:hover:not(.active) {
    background: var(--bg);
}

.arvan-tab-card {
    display: flex;
    flex-direction: column;
    background: var(--sf);
    border-radius: 16px;
    border: 1px solid var(--bd);
    box-shadow: 0 4px 20px rgba(0,0,0,0.03);
    overflow: hidden;
}

.arvan-sidebar {
    background: var(--sf2);
    border-bottom: 1px solid var(--bd);
}

.arvan-sub-tabs {
    display: flex;
    overflow-x: auto;
    padding: 10px 15px;
    gap: 5px;
}
.arvan-sub-tab-btn {
    padding: 10px 18px;
    background: transparent;
    border: none;
    border-radius: 8px;
    color: var(--text2);
    cursor: pointer;
    transition: all 0.2s;
    font-size: 0.9rem;
    white-space: nowrap;
    outline: none;
}
.arvan-sub-tab-btn.active {
    background: var(--ac);
    color: var(--btn-ac-text, #fff);
    font-weight: 600;
}
.arvan-sub-tab-btn:hover:not(.active) {
    background: var(--sf3);
    color: var(--text);
}

.arvan-content-area {
    flex: 1;
    min-width: 0;
    padding: 25px;
}

@media (min-width: 768px) {
    .arvan-tab-card {
        flex-direction: row;
        min-height: 500px;
    }
    .arvan-sidebar {
        width: 240px;
        flex-shrink: 0;
        border-bottom: none;
        border-left: 1px solid var(--bd);
    }
    .arvan-sub-tabs {
        flex-direction: column;
        padding: 20px 10px;
        gap: 8px;
        overflow-x: visible;
    }
    .arvan-sub-tab-btn {
        text-align: right;
        padding: 12px 15px;
    }
}

.arvan-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
    gap: 20px;
}
.toggle-field {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    padding: 14px 18px;
    background: var(--sf);
    border-radius: 12px;
    border: 1px solid var(--bd);
    gap: 12px;
    text-align: right;
    transition: all 0.2s ease;
}
.toggle-field:hover {
    border-color: var(--ac);
    background: var(--sf2);
    box-shadow: 0 0 0 2px var(--acs);
}
.toggle-texts {
    display: flex;
    flex-direction: column;
    gap: 4px;
    align-items: flex-start;
}
.toggle-label {
    font-size: 0.85rem;
    font-weight: 600;
    color: var(--text);
    margin: 0;
    line-height: 1.4;
    cursor: pointer;
}
.toggle-state {
    font-size: 0.72rem;
    color: var(--ac);
    font-weight: 500;
}

.arvan-select {
    width: 100%;
    padding: 10px 12px;
    padding-left: 35px;
    border-radius: 8px;
    border: 1.5px solid var(--bd);
    background: var(--sf2);
    color: var(--text);
    font-family: var(--font);
    font-size: 0.85rem;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    color-scheme: inherit;
    background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2394A3B8' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: left 10px center;
    background-size: 15px;
    transition: all 0.2s ease;
    outline: 0;
}
.arvan-select:hover {
    border-color: var(--bds);
}
.arvan-select:focus {
    border-color: var(--ac);
    box-shadow: 0 0 0 3px var(--acs);
}
.arvan-input {
    width: 100%;
    padding: 10px 12px;
    border-radius: 8px;
    border: 1.5px solid var(--bd);
    background: var(--sf2);
    color: var(--text);
    font-family: var(--font);
    font-size: 0.85rem;
    transition: all 0.2s ease;
    outline: 0;
}
.arvan-input::placeholder {
    color: var(--dim);
}
.arvan-input:hover {
    border-color: var(--bds);
}
.arvan-input:focus {
    border-color: var(--ac);
    box-shadow: 0 0 0 3px var(--acs);
}
@media (max-width: 768px) {
    .arvan-grid {
        grid-template-columns: 1fr 1fr;
        gap: 10px;
    }
    .field:not(.toggle-field) {
        grid-column: 1 / -1;
    }
}
@media (max-width: 480px) {
    .arvan-grid {
        grid-template-columns: 1fr 1fr;
        gap: 8px;
    }
    .field:not(.toggle-field) {
        grid-column: 1 / -1;
    }
    .toggle-field {
        flex-direction: row;
        padding: 12px 14px;
        gap: 8px;
    }
    .toggle-label {
        font-size: 0.8rem;
    }
    .toggle-state {
        font-size: 0.68rem;
    }
}
@media (max-width: 600px) {
    .arvan-main-tabs, .arvan-sub-tabs {
        -ms-overflow-style: none; /* IE and Edge */
        scrollbar-width: none; /* Firefox */
    }
    .arvan-main-tabs::-webkit-scrollbar, .arvan-sub-tabs::-webkit-scrollbar {
        display: none; /* Chrome, Safari and Opera */
    }
    .arvan-main-tabs {
        gap: 6px;
        justify-content: space-between;
    }
    .arvan-main-tab-btn {
        padding: 8px 4px;
        font-size: 0.65rem;
        border-radius: 8px;
        flex-direction: column;
        gap: 6px;
        flex: 1;
        min-width: 0;
    }
    .arvan-main-tab-btn span {
        white-space: normal;
        line-height: 1.2;
        text-align: center;
        font-size: 0.65rem;
    }
    .arvan-main-tab-btn svg {
        width: 20px !important;
        height: 20px !important;
    }
    .arvan-sub-tabs {
        flex-wrap: wrap;
        justify-content: center;
        gap: 8px;
        border-bottom: none;
        padding-bottom: 10px;
    }
    .arvan-sub-tab-btn {
        padding: 8px 14px;
        font-size: 0.8rem;
        background: var(--bg);
        border: 1px solid var(--bd) !important;
        border-radius: 10px;
        margin: 0;
        flex: 1 1 auto;
        text-align: center;
    }
    .arvan-sub-tab-btn.active {
        background: var(--ac);
        color: var(--btn-ac-text, #fff) !important;
        border-color: var(--ac) !important;
    }
    .card-head {
        padding: 0 10px !important;
    }
    .card-body {
        padding: 15px !important;
    }
}

/* Toggle Switch Styles */
.arvan-switch {
    position: relative;
    display: inline-block;
    width: 46px;
    height: 26px;
    flex-shrink: 0;
    direction: ltr;
}
.arvan-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}
.arvan-slider {
    position: absolute;
    cursor: pointer;
    top: 0; left: 0; right: 0; bottom: 0;
    background-color: var(--sf3);
    transition: .3s ease;
    border-radius: 26px;
    border: 1px solid var(--bd);
}
.arvan-slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 2px;
    bottom: 2px;
    background-color: #fff;
    transition: .3s ease;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0,0,0,0.15);
}
input:checked + .arvan-slider {
    background-color: var(--ac);
    border-color: var(--ac);
}
input:checked + .arvan-slider:before {
    transform: translateX(20px);
}
</style>

<div class="fade-up">
    <!-- Main Tabs -->
    <div class="arvan-main-tabs">
        <?php foreach ($schema as $key => $tab_data): ?>
            <button type="button" class="arvan-main-tab-btn <?= $tab === $key ? 'active' : '' ?>" data-tab="<?= $key ?>">
                <?= icon($tab_data['icon'] ?? 'settings', 22) ?>
                <span style="font-weight: 600;"><?= $tab_data['title'] ?></span>
            </button>
        <?php endforeach; ?>
    </div>

    <form method="POST" id="settingsForm" enctype="multipart/form-data" hx-boost="false">
        <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="current_tab" id="current_tab_input" value="<?= htmlspecialchars($tab) ?>">
        <input type="hidden" name="current_sec" id="current_sec_input" value="<?= htmlspecialchars($sec) ?>">
        
        <?php foreach ($schema as $key => $tab_data): ?>
            <div class="arvan-tab-content" id="tab-content-<?= $key ?>" style="display: <?= $tab === $key ? 'block' : 'none' ?>;">
                
                <div class="arvan-tab-card">
                    <!-- Sidebar Sub Tabs -->
                    <div class="arvan-sidebar">
                        <div class="arvan-sub-tabs">
                            <?php $isFirstSec = true; foreach ($tab_data['sections'] as $section_title => $fields): ?>
                                <?php 
                                    $isActiveSec = false;
                                    if ($tab === $key && $sec === $section_title) $isActiveSec = true;
                                    elseif ($tab !== $key && $isFirstSec && $sec === '') $isActiveSec = true;
                                    elseif ($tab !== $key && $isFirstSec && !isset($schema[$key]['sections'][$sec])) $isActiveSec = true;
                                ?>
                                <button type="button" class="arvan-sub-tab-btn <?= $isActiveSec ? 'active' : '' ?>" data-tab="<?= $key ?>" data-sec="<?= htmlspecialchars($section_title) ?>">
                                    <?= htmlspecialchars($section_title) ?>
                                </button>
                            <?php $isFirstSec = false; endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="arvan-content-area">
                        <?php $isFirstSec = true; foreach ($tab_data['sections'] as $section_title => $fields): ?>
                            <?php 
                                $isActiveSec = false;
                                if ($tab === $key && $sec === $section_title) $isActiveSec = true;
                                elseif ($tab !== $key && $isFirstSec && $sec === '') $isActiveSec = true;
                                elseif ($tab !== $key && $isFirstSec && !isset($schema[$key]['sections'][$sec])) $isActiveSec = true;
                            ?>
                            <div class="arvan-section-content" data-tab="<?= $key ?>" data-sec="<?= htmlspecialchars($section_title) ?>" style="display: <?= $isActiveSec ? 'block' : 'none' ?>;">
                                <h3 style="font-size: 1.1rem; font-weight: 700; margin-bottom: 20px; color: var(--text);"><?= htmlspecialchars($section_title) ?></h3>
                                <div class="arvan-grid">
                                    <?php foreach($fields as $f): ?>
                                        <?php if($f['type'] === 'select'): 
                                            $keys = array_keys($f['options']);
                                            $val1 = $keys[0]; 
                                            $val2 = $keys[1]; 
                                            $currentVal = (strval($f['val']) === strval($val1)) ? $val1 : $val2;
                                            $isChecked = ($currentVal === $val1);
                                        ?>
                                            <div class="field toggle-field">
                                                <div class="toggle-texts">
                                                    <label class="toggle-label" for="chk_<?= $f['name'] ?>"><?= $f['label'] ?></label>
                                                    <span class="toggle-state"><?= $isChecked ? $f['options'][$val1] : $f['options'][$val2] ?></span>
                                                </div>
                                                <input type="hidden" name="<?= $f['name'] ?>" id="hidden_<?= $f['name'] ?>" value="<?= htmlspecialchars($currentVal) ?>">
                                                <label class="arvan-switch">
                                                    <input type="checkbox" id="chk_<?= $f['name'] ?>" <?= $isChecked ? 'checked' : '' ?> onchange="document.getElementById('hidden_<?= $f['name'] ?>').value = this.checked ? '<?= $val1 ?>' : '<?= $val2 ?>'; this.closest('.toggle-field').querySelector('.toggle-state').innerText = this.checked ? '<?= $f['options'][$val1] ?>' : '<?= $f['options'][$val2] ?>';">
                                                    <span class="arvan-slider"></span>
                                                </label>
                                            </div>
                                        <?php elseif($f['type'] === 'text' || $f['type'] === 'number'): ?>
                                            <div class="field" style="display: flex; flex-direction: column; gap: 6px;">
                                                <label class="field" style="font-weight: 600; color: var(--text2); font-size: 0.78rem;"><?= htmlspecialchars($f['label']) ?></label>
                                                <input type="<?= $f['type'] ?>" name="<?= $f['name'] ?>" class="arvan-input" value="<?= htmlspecialchars($f['val'] ?? '') ?>" placeholder="<?= htmlspecialchars($f['placeholder'] ?? '') ?>">
                                            </div>
                                        <?php elseif($f['type'] === 'file'): ?>
                                            <div class="field" style="display: flex; flex-direction: column; gap: 6px;">
                                                <label class="field" style="font-weight: 600; color: var(--text2); font-size: 0.78rem;"><?= htmlspecialchars($f['label']) ?></label>
                                                <input type="<?= $f['type'] ?>" name="<?= $f['name'] ?>" class="arvan-input" style="padding: 7px 10px;" accept="<?= htmlspecialchars($f['accept'] ?? '') ?>">
                                                <?php if(!empty($f['hint'])): ?>
                                                    <small style="color: var(--mute); font-size: 0.7rem;"><?= htmlspecialchars($f['hint']) ?></small>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php $isFirstSec = false; endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        
        <div style="margin-top: 25px; display: flex; justify-content: flex-end;">
            <button type="submit" class="btn btn-primary" style="padding: 12px 35px; font-size: 1rem; border-radius: 8px; display:flex; align-items:center; gap:8px;">
                <?= icon('check', 18) ?> ذخیره تغییرات
            </button>
        </div>
    </form>
</div>

<script>
(function() {
    const mainTabs = document.querySelectorAll('.arvan-main-tab-btn');
    const subTabs = document.querySelectorAll('.arvan-sub-tab-btn');
    const tabContents = document.querySelectorAll('.arvan-tab-content');
    const secContents = document.querySelectorAll('.arvan-section-content');
    
    mainTabs.forEach(btn => {
        btn.onclick = function() {
            mainTabs.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const targetTab = this.getAttribute('data-tab');
            document.getElementById('current_tab_input').value = targetTab;
            
            tabContents.forEach(c => c.style.display = 'none');
            const targetContent = document.getElementById('tab-content-' + targetTab);
            if(targetContent) targetContent.style.display = 'block';
            
            const targetSubTabs = document.querySelectorAll(`.arvan-sub-tab-btn[data-tab="${targetTab}"]`);
            if (targetSubTabs.length > 0) {
                const activeSubTab = Array.from(targetSubTabs).find(st => st.classList.contains('active'));
                if (!activeSubTab) {
                    targetSubTabs[0].click();
                } else {
                    document.getElementById('current_sec_input').value = activeSubTab.getAttribute('data-sec');
                }
            }
        };
    });
    
    subTabs.forEach(btn => {
        btn.onclick = function() {
            const targetTab = this.getAttribute('data-tab');
            const targetSec = this.getAttribute('data-sec');
            
            const siblingTabs = document.querySelectorAll(`.arvan-sub-tab-btn[data-tab="${targetTab}"]`);
            siblingTabs.forEach(b => b.classList.remove('active'));
            
            this.classList.add('active');
            document.getElementById('current_sec_input').value = targetSec;
            
            const siblingContents = document.querySelectorAll(`.arvan-section-content[data-tab="${targetTab}"]`);
            siblingContents.forEach(c => c.style.display = 'none');
            
            const targetContent = Array.from(siblingContents).find(c => c.getAttribute('data-sec') === targetSec);
            if (targetContent) {
                targetContent.style.display = 'block';
            }
        };
    });
})();
</script>

<?php include __DIR__ . '/inc/layout_foot.php'; ?>

